# E-commerce SOLID

Trabalho de refatoração do OrderController usando SOLID. Express + Prisma + SQLite.

## Como rodar

```bash
npm install
npm run prisma:migrate
npm run prisma:seed
npm run dev
```

O servidor sobe em http://localhost:3000. A primeira vez demora um pouco por causa do Ethereal Mail.

## O que eu fiz

- **SRP**: o controller agora só cuida do HTTP. O OrderService faz o fluxo do pedido, o NotificationService monta o email e os repositories mexem no banco.
- **OCP**: criei a interface IPaymentMethod e uma classe pra cada pagamento (cartão de crédito, débito e pix). O PaymentMethodRegistry guarda todos, então pra adicionar um novo não precisa mexer no OrderService.
- **LSP**: Product tem o calculateFreight(). O PhysicalProduct cobra 10 de frete e o DigitalProduct não cobra nada. A ProductFactory cria o certo a partir do que vem do banco.
- **ISP**: as interfaces são pequenas (IMailProvider, IOrderRepository, IProductRepository, IPaymentMethod).
- **DIP**: o OrderService só conhece as interfaces. As classes de verdade são criadas no app.ts.

## Pastas

```text
src/
├── controllers/
├── domain/
├── services/
├── providers/
├── repositories/
├── payments/
├── errors/
├── app.ts
└── server.ts
```

## Testando

Livro físico (com frete de R$ 10):

```bash
curl -X POST http://localhost:3000/orders \
-H "Content-Type: application/json" \
-d '{
  "customer": "abacaxi123@ethereal.email",
  "items": [{ "productId": 1, "quantity": 1 }],
  "paymentMethod": "credit_card",
  "paymentDetails": { "cardNumber": "1234567812345678", "cvv": "123" }
}'
```

E-book (sem frete):

```bash
curl -X POST http://localhost:3000/orders \
-H "Content-Type: application/json" \
-d '{
  "customer": "abacate123@ethereal.email",
  "items": [{ "productId": 2, "quantity": 1 }],
  "paymentMethod": "credit_card",
  "paymentDetails": { "cardNumber": "1234567812345678", "cvv": "123" }
}'
```

Pix:

```bash
curl -X POST http://localhost:3000/orders \
-H "Content-Type: application/json" \
-d '{
  "customer": "abacaxi123@ethereal.email",
  "items": [{ "productId": 1, "quantity": 1 }],
  "paymentMethod": "pix"
}'
```
