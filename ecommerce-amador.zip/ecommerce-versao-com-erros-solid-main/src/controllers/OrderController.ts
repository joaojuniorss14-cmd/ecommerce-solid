import { Request, Response } from 'express';
import { OrderService } from '../services/OrderService';
import { AppError } from '../errors/AppError';

export class OrderController {
  orderService: OrderService;

  constructor(orderService: OrderService) {
    this.orderService = orderService;
  }

  processOrder = async (req: Request, res: Response) => {
    try {
      const result = await this.orderService.processOrder(req.body);

      return res.json({
        message: 'Pedido processado com sucesso',
        orderId: result.orderId,
        emailPreview: result.emailPreview,
      });
    } catch (error: any) {
      if (error instanceof AppError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      console.log('Erro ao processar pedido: ' + error.message);
      return res.status(500).json({ error: 'Erro interno' });
    }
  };
}
