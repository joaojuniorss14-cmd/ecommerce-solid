import { IMailProvider } from '../providers/IMailProvider';

export class NotificationService {
  mailProvider: IMailProvider;

  constructor(mailProvider: IMailProvider) {
    this.mailProvider = mailProvider;
  }

  async sendOrderConfirmation(order: any, items: any[]) {
    let lista = '';
    for (let i = 0; i < items.length; i++) {
      lista += '<li>' + items[i].name + '</li>';
    }

    const result = await this.mailProvider.sendMail({
      from: '"DevStore" <noreply@devstore.com>',
      to: order.customer,
      subject: 'Confirmação do Pedido #' + order.id,
      text: 'Olá, seu pedido #' + order.id + ' no valor de R$ ' + order.total + ' foi confirmado.',
      html:
        '<h1>Pedido Confirmado!</h1>' +
        '<p>Olá, seu pedido <b>#' + order.id + '</b> foi processado com sucesso.</p>' +
        '<p>Total: <strong>R$ ' + order.total + '</strong></p>' +
        '<ul>' + lista + '</ul>',
    });

    return result.previewUrl;
  }
}
