import { ProductFactory } from '../domain/ProductFactory';
import { PaymentMethodRegistry } from '../payments/PaymentMethodRegistry';
import { IOrderRepository } from '../repositories/IOrderRepository';
import { IProductRepository } from '../repositories/IProductRepository';
import { NotificationService } from './NotificationService';
import { AppError } from '../errors/AppError';

export class OrderService {
  productRepository: IProductRepository;
  orderRepository: IOrderRepository;
  paymentMethods: PaymentMethodRegistry;
  notificationService: NotificationService;

  constructor(
    productRepository: IProductRepository,
    orderRepository: IOrderRepository,
    paymentMethods: PaymentMethodRegistry,
    notificationService: NotificationService
  ) {
    this.productRepository = productRepository;
    this.orderRepository = orderRepository;
    this.paymentMethods = paymentMethods;
    this.notificationService = notificationService;
  }

  async processOrder(input: any) {
    if (!input.items || input.items.length == 0) {
      console.log('Tentativa de pedido sem itens');
      throw new AppError('Carrinho vazio', 400);
    }

    for (let i = 0; i < input.items.length; i++) {
      const q = input.items[i].quantity;
      if (!Number.isInteger(q) || q <= 0) {
        throw new AppError('Quantidade inválida', 400);
      }
    }

    let total = 0;
    const orderItems: any[] = [];

    for (let i = 0; i < input.items.length; i++) {
      const item = input.items[i];
      const data = await this.productRepository.findById(item.productId);
      if (!data) {
        throw new AppError('Produto ' + item.productId + ' não encontrado', 400);
      }

      const product = ProductFactory.createProduct(data);
      const freight = product.calculateFreight();

      total = total + product.price * item.quantity + freight;

      orderItems.push({
        id: product.id,
        name: product.name,
        type: product.type,
        price: product.price,
        freight: freight,
        quantity: item.quantity,
      });
    }

    const payment = this.paymentMethods.get(input.paymentMethod);
    await payment.process(total, input.paymentDetails);

    const order = await this.orderRepository.create({
      customer: input.customer,
      items: orderItems,
      total: total,
      status: 'confirmed',
    });

    const emailPreview = await this.notificationService.sendOrderConfirmation(order, orderItems);
    console.log('Email enviado: ' + emailPreview);

    return { orderId: order.id, emailPreview: emailPreview };
  }
}
