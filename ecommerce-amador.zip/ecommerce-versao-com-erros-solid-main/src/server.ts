import app from './app';

app.listen(3000, () => {
  console.log('Server rodando em http://localhost:3000');
});
