import { Product } from './IProduct';

export class DigitalProduct implements Product {
  id: number;
  name: string;
  price: number;
  type = 'digital';

  constructor(id: number, name: string, price: number) {
    this.id = id;
    this.name = name;
    this.price = price;
  }

  calculateFreight() {
    return 0;
  }
}
