import { PrismaClient } from '@prisma/client';
import { IProductRepository } from './IProductRepository';

export class PrismaProductRepository implements IProductRepository {
  prisma: PrismaClient;

  constructor(prisma: PrismaClient) {
    this.prisma = prisma;
  }

  async findById(id: number) {
    return await this.prisma.product.findUnique({ where: { id: id } });
  }
}
