export interface IOrderRepository {
  create(data: any): Promise<any>;
}
