import express from 'express';
import { PrismaClient } from '@prisma/client';
import { OrderController } from './controllers/OrderController';
import { OrderService } from './services/OrderService';
import { NotificationService } from './services/NotificationService';
import { EtherealMailProvider } from './providers/EtherealMailProvider';
import { PrismaOrderRepository } from './repositories/PrismaOrderRepository';
import { PrismaProductRepository } from './repositories/PrismaProductRepository';
import { PaymentMethodRegistry } from './payments/PaymentMethodRegistry';
import { CreditCardPayment } from './payments/CreditCardPayment';
import { DebitCardPayment } from './payments/DebitCardPayment';
import { PixPayment } from './payments/PixPayment';

const app = express();
app.use(express.json());

const prisma = new PrismaClient();

const paymentMethods = new PaymentMethodRegistry();
paymentMethods.register('credit_card', new CreditCardPayment());
paymentMethods.register('debit_card', new DebitCardPayment());
paymentMethods.register('pix', new PixPayment());

const productRepository = new PrismaProductRepository(prisma);
const orderRepository = new PrismaOrderRepository(prisma);
const mailProvider = new EtherealMailProvider();
const notificationService = new NotificationService(mailProvider);

const orderService = new OrderService(
  productRepository,
  orderRepository,
  paymentMethods,
  notificationService
);

const orderController = new OrderController(orderService);

app.post('/orders', orderController.processOrder);

export default app;
