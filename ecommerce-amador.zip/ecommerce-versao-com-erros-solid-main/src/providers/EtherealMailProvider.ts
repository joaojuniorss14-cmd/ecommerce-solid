import nodemailer from 'nodemailer';
import { IMailProvider } from './IMailProvider';

export class EtherealMailProvider implements IMailProvider {
  transporter: any = null;

  async getTransporter() {
    if (this.transporter) {
      return this.transporter;
    }

    const account = await nodemailer.createTestAccount();

    this.transporter = nodemailer.createTransport({
      host: account.smtp.host,
      port: account.smtp.port,
      secure: account.smtp.secure,
      auth: {
        user: account.user,
        pass: account.pass,
      },
    });

    console.log('Ethereal configurado: ' + account.user);
    return this.transporter;
  }

  async sendMail(message: any) {
    const transporter = await this.getTransporter();
    const info = await transporter.sendMail(message);
    const url = nodemailer.getTestMessageUrl(info);
    return { previewUrl: url };
  }
}
