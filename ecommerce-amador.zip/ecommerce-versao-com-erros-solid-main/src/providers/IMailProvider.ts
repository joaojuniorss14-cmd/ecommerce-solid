export interface IMailProvider {
  sendMail(message: any): Promise<any>;
}
