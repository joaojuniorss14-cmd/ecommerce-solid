import { IPaymentMethod } from './IPaymentMethod';

export class PixPayment implements IPaymentMethod {
  async process(amount: number, details?: any) {
    console.log('Processando Pix no valor de R$ ' + amount);
  }
}
