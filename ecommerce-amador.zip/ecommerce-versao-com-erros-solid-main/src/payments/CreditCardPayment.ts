import { IPaymentMethod } from './IPaymentMethod';
import { AppError } from '../errors/AppError';

export class CreditCardPayment implements IPaymentMethod {
  async process(amount: number, details?: any) {
    if (!details || !details.cardNumber || !details.cvv) {
      throw new AppError('Dados do cartão inválidos', 400);
    }

    console.log('Processando cartão final ' + details.cardNumber.slice(-4));

    if (details.cvv == '000') {
      throw new Error('Cartão recusado');
    }
  }
}
