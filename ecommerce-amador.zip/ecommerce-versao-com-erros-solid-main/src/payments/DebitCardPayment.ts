import { IPaymentMethod } from './IPaymentMethod';

export class DebitCardPayment implements IPaymentMethod {
  async process(amount: number, details?: any) {
    console.log('Processando débito...');
  }
}
