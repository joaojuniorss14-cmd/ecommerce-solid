import { IPaymentMethod } from './IPaymentMethod';
import { AppError } from '../errors/AppError';

export class PaymentMethodRegistry {
  methods: any = {};

  register(name: string, method: IPaymentMethod) {
    this.methods[name] = method;
    return this;
  }

  get(name: string): IPaymentMethod {
    const method = this.methods[name];
    if (!method) {
      throw new AppError('Método de pagamento não suportado', 400);
    }
    return method;
  }
}
